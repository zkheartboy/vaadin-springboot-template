package org.zk.ui.views.orderedit;

public class ProductInfoChangeEvent {

	public ProductInfoChangeEvent() {
		// Nothing to do here
	}
}
