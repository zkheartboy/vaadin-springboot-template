package org.zk.ui;

public class MainViewElement extends MainViewDesignElement {

}