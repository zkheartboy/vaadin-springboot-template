package org.zk.ui.views.admin.product;

public class ProductAdminViewElement extends ProductAdminViewDesignElement implements CrudViewElement {

}