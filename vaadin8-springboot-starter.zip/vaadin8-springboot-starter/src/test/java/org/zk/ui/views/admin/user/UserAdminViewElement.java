package org.zk.ui.views.admin.user;

import org.zk.ui.views.admin.product.CrudViewElement;

public class UserAdminViewElement extends UserAdminViewDesignElement implements CrudViewElement {

}