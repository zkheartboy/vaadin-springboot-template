/**
 * 
 */
package org.zk.ui.components;

import com.vaadin.flow.component.cookieconsent.CookieConsent;


public class BakeryCookieConsent extends CookieConsent {

	public BakeryCookieConsent() {
		setPosition(Position.BOTTOM);
	}

}
