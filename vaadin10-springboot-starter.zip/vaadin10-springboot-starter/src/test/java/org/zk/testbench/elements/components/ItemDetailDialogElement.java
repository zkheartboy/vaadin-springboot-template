package org.zk.testbench.elements.components;

import com.vaadin.testbench.TestBenchElement;
import com.vaadin.testbench.elementsbase.Element;

@Element("item-detail-dialog")
public class ItemDetailDialogElement extends TestBenchElement {

}
